/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_user_registration_sessions`; */
/* PRE_TABLE_NAME: `1712320598_wp_user_registration_sessions`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1712320598_wp_user_registration_sessions` ( `session_id` bigint unsigned NOT NULL AUTO_INCREMENT, `session_key` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL, `session_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL, `session_expiry` bigint unsigned NOT NULL, PRIMARY KEY (`session_key`), UNIQUE KEY `session_id` (`session_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
